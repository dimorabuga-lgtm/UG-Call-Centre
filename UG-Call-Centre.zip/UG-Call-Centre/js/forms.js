document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('#consultation-form');
  if (!form) return;

  const phone = form.querySelector('#lead-phone');
  const comment = form.querySelector('#lead-comment');
  const counter = form.querySelector('#comment-count');
  const submit = form.querySelector('[type="submit"]');
  const selectedPlan = form.querySelector('[data-selected-plan]');

  const setError = (field, text) => {
    const target = form.querySelector(`#${field.dataset.errorTarget}-error`);
    field.setAttribute('aria-invalid', String(Boolean(text)));
    if (target) target.textContent = text;
  };

  const normalizePhone = (value) => {
    let digits = value.replace(/\D/g, '');

    if (digits === '38') return '';
    if (digits.startsWith('380')) digits = digits.slice(2);
    else if (digits.startsWith('38') && digits.length > 10) digits = digits.slice(2);
    if (digits && !digits.startsWith('0')) digits = `0${digits}`;

    return digits.slice(0, 10);
  };

  const formatPhone = (value) => {
    const digits = normalizePhone(value);
    let result = '+38';

    if (digits.length) result += ` (${digits.slice(0, 3)}`;
    if (digits.length >= 3) result += `) ${digits.slice(3, 6)}`;
    if (digits.length >= 6) result += `-${digits.slice(6, 8)}`;
    if (digits.length >= 8) result += `-${digits.slice(8, 10)}`;

    return result;
  };

  const caretAfterDigits = (value, digitCount) => {
    if (!digitCount) return Math.min(value.length, 3);
    let seen = 0;

    for (let index = 3; index < value.length; index += 1) {
      if (/\d/.test(value[index])) seen += 1;
      if (seen === digitCount) return index + 1;
    }

    return value.length;
  };

  phone.addEventListener('input', () => {
    const cursor = phone.selectionStart || phone.value.length;
    const digitsBeforeCursor = normalizePhone(phone.value.slice(0, cursor)).length;
    const formatted = formatPhone(phone.value);

    phone.value = formatted;
    const nextCursor = caretAfterDigits(formatted, digitsBeforeCursor);
    phone.setSelectionRange(nextCursor, nextCursor);
  });

  comment?.addEventListener('input', () => {
    counter.textContent = `${comment.value.length} / 500`;
  });

  document.querySelectorAll('[data-plan-choice]').forEach((link) => {
    link.addEventListener('click', () => {
      if (selectedPlan) selectedPlan.value = link.dataset.planChoice || '';
    });
  });

  const params = new URLSearchParams(window.location.search);
  const crm = form.querySelector('#lead-crm');
  const task = form.querySelector('#lead-task');
  if (selectedPlan && params.get('tariff')) selectedPlan.value = params.get('tariff');
  if (crm && params.get('crm')) crm.value = params.get('crm');
  if (task && params.get('task')) task.value = params.get('task');

  form.addEventListener('submit', (event) => {
    const name = form.querySelector('#lead-name');
    const leads = form.querySelector('#lead-leads');
    const consent = form.querySelector('#lead-consent');
    const phoneDigits = normalizePhone(phone.value);
    const isNameValid = name.value.trim().length >= 2 && !/^\d+$/.test(name.value.trim());
    const isPhoneValid = phoneDigits.length === 10 && phoneDigits.startsWith('0');
    const isLeadsValid = Boolean(leads.value);
    const isCrmValid = Boolean(crm?.value);
    const isTaskValid = Boolean(task?.value);

    setError(name, isNameValid ? '' : 'Вкажіть, будь ласка, ваше ім’я.');
    setError(phone, isPhoneValid ? '' : 'Вкажіть коректний номер телефону.');
    setError(leads, isLeadsValid ? '' : 'Оберіть кількість заявок.');
    if (crm) setError(crm, isCrmValid ? '' : 'Оберіть CRM.');
    if (task) setError(task, isTaskValid ? '' : 'Оберіть основне завдання.');
    setError(consent, consent.checked ? '' : 'Підтвердіть згоду на обробку даних.');

    if (!isNameValid || !isPhoneValid || !isLeadsValid || !isCrmValid || !isTaskValid || !consent.checked) {
      event.preventDefault();
      return;
    }

    phone.value = formatPhone(phoneDigits);
    submit.disabled = true;
    submit.innerHTML = 'Надсилаємо… <span class="form-spinner" aria-hidden="true"></span>';
  });
});
