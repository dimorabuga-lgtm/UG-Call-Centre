(() => {
  'use strict';

  const initialiseCalculator = () => {
    const calculator = document.querySelector('[data-benefit-calculator]');
    if (!calculator) return;

    const fields = [...calculator.querySelectorAll('[data-calculator-input]')];
    const ranges = [...calculator.querySelectorAll('[data-calculator-range]')];
    const message = calculator.querySelector('.benefit-calculator__message');
    const results = Object.fromEntries([...calculator.querySelectorAll('[data-calculator-result]')].map((item) => [item.dataset.calculatorResult, item]));
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const numberFormat = new Intl.NumberFormat('uk-UA', { maximumFractionDigits: 0 });

    const normalise = (input, showMessage = false) => {
      const min = Number(input.min);
      const max = Number(input.max);
      let value = Number(input.value);
      if (!Number.isFinite(value)) {
        value = min;
        if (showMessage) message.textContent = 'Введіть число в допустимому діапазоні.';
      }
      const bounded = Math.min(max, Math.max(min, Math.round(value)));
      if (showMessage && bounded !== value) message.textContent = `Значення скориговано до діапазону ${min}–${max}.`;
      input.value = String(bounded);
      return bounded;
    };

    const animateValue = (element, target, suffix = '', prefix = '') => {
      const from = Number(element.dataset.currentValue || 0);
      if (reducedMotion) {
        element.textContent = `${prefix}${numberFormat.format(target)}${suffix}`;
        element.dataset.currentValue = String(target);
        return;
      }
      const startedAt = performance.now();
      const update = (now) => {
        const progress = Math.min((now - startedAt) / 520, 1);
        const value = Math.round(from + (target - from) * (1 - Math.pow(1 - progress, 3)));
        element.textContent = `${prefix}${numberFormat.format(value)}${suffix}`;
        if (progress < 1) window.requestAnimationFrame(update);
        else element.dataset.currentValue = String(target);
      };
      window.requestAnimationFrame(update);
    };

    const calculate = (preserveMessage = false) => {
      if (!preserveMessage) message.textContent = '';
      const values = Object.fromEntries(fields.map((field) => [field.dataset.calculatorInput, normalise(field)]));
      ranges.forEach((range) => {
        const input = calculator.querySelector(`[data-calculator-input="${range.dataset.calculatorRange}"]`);
        if (input) range.value = input.value;
      });
      const currentOrders = Math.round(values.leads * values.days * values.approval / 100);
      const potentialApproval = Math.min(95, values.approval + 12);
      const potentialUpsell = Math.min(10000, values.upsell + 350);
      const potentialOrders = Math.round(values.leads * values.days * potentialApproval / 100);
      const currentRevenue = currentOrders * (values.average + values.upsell);
      const potentialRevenue = potentialOrders * (values.average + potentialUpsell);
      animateValue(results['current-orders'], currentOrders);
      animateValue(results['potential-orders'], potentialOrders);
      animateValue(results['current-revenue'], currentRevenue, ' грн');
      animateValue(results.difference, Math.max(0, potentialRevenue - currentRevenue), ' грн', '+');
    };

    fields.forEach((field) => {
      field.addEventListener('input', calculate);
      field.addEventListener('blur', () => { normalise(field, true); calculate(true); });
    });
    ranges.forEach((range) => {
      range.addEventListener('input', () => {
        const input = calculator.querySelector(`[data-calculator-input="${range.dataset.calculatorRange}"]`);
        if (input) input.value = range.value;
        calculate();
      });
    });
    calculate();
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialiseCalculator, { once: true });
  else initialiseCalculator();
})();
